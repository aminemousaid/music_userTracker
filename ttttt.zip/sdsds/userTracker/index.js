// userTracker.js
const { EmbedBuilder, REST, Routes, SlashCommandBuilder } = require('discord.js');
const moment = require('moment-timezone');

module.exports = (client, config) => {
    let lastStatus = null;
    let dailyReport = { onlineCount: 0, offlineCount: 0, events: [] };

    async function deleteLastMessages(user, amount = 5) {
        try {
            const dm = await user.createDM();
            const messages = await dm.messages.fetch({ limit: amount });
            for (const message of messages.values()) {
                await message.delete().catch(err => console.log('Cannot delete message:', err));
            }
        } catch (err) {
            console.log('Error deleting messages:', err);
        }
    }

    client.once('ready', async () => {
        console.log('✅ User Tracker ready');

        // Register slash commands
        const commands = [
            new SlashCommandBuilder()
                .setName('report')
                .setDescription('Get the current daily report')
        ].map(cmd => cmd.toJSON());

        const rest = new REST({ version: '10' }).setToken(config.TOKEN);
        await rest.put(Routes.applicationGuildCommands(client.user.id, config.GUILD_ID), { body: commands });
    });

    client.on('presenceUpdate', async (oldPresence, newPresence) => {
        if (newPresence.userId !== config.USER_ID) return;

        const status = newPresence.status;
        if (status === lastStatus) return;
        lastStatus = status;

        const now = moment().tz('Africa/Casablanca').format('HH:mm:ss');

        if (status === 'online') dailyReport.onlineCount++;
        if (status === 'offline' || status === 'idle') dailyReport.offlineCount++;

        let statusEmoji = '';
        let embedColor = '#808080'; // offline gray

        switch (status) {
            case 'online':
                statusEmoji = '<:online:1419059961522032651>';
                embedColor = '#00ff00';
                break;
            case 'idle':
                statusEmoji = '<:idle:1419059994115964968>';
                embedColor = '#FFA500';
                break;
            case 'dnd':
                statusEmoji = '<:dnd:1419060015221706822>';
                embedColor = '#FF0000';
                break;
            case 'offline':
                statusEmoji = '<:offline:1419061006172422306>';
                embedColor = '#808080';
                break;
        }

        dailyReport.events.push({ status: status.toUpperCase(), statusEmoji, time: now });

        const embed = new EmbedBuilder()
            .setTitle('🔔 Status Update')
            .setDescription(`User <@${config.USER_ID}> status changed`)
            .addFields(
                { name: 'New Status', value: `${statusEmoji} ${status.toUpperCase()}`, inline: true },
                { name: 'Time', value: now, inline: true }
            )
            .setColor(embedColor)
            .setFooter({ text: 'Bot Tracker', iconURL: client.user.avatarURL() })
            .setTimestamp();

        const owner = await client.users.fetch(config.OWNER_ID);
        await deleteLastMessages(owner, 5);
        owner.send({ embeds: [embed] }).catch(err => console.log("Can't send DM:", err));
    });

    client.on('interactionCreate', async interaction => {
        if (!interaction.isChatInputCommand()) return;
        if (interaction.user.id !== config.OWNER_ID) {
            return interaction.reply({ content: '❌ You are not allowed to use this command.', ephemeral: true });
        }

        if (interaction.commandName === 'report') {
            const todayDate = moment().tz('Africa/Casablanca').format('YYYY-MM-DD');
            const embed = new EmbedBuilder()
                .setTitle('📊 Current Daily Report')
                .setDescription(`Date: ${todayDate}`)
                .addFields(
                    { name: 'Total Online', value: dailyReport.onlineCount.toString(), inline: true },
                    { name: 'Total Offline', value: dailyReport.offlineCount.toString(), inline: true },
                    { name: 'Events', value: dailyReport.events.map(e => `${e.time} - ${e.statusEmoji} ${e.status}`).join('\n') || 'No events yet' }
                )
                .setColor('#0099ff')
                .setFooter({ text: 'Bot Tracker', iconURL: client.user.avatarURL() })
                .setTimestamp();

            const owner = await client.users.fetch(config.OWNER_ID);
            await deleteLastMessages(owner, 5);
            owner.send({ embeds: [embed] }).catch(err => console.log("Can't send DM:", err));

            interaction.reply({ content: '✅ Report sent to your DM.', ephemeral: true });
        }
    });
};
