const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const ytdl = require('ytdl-core');
const { joinVoiceChannel, createAudioPlayer, createAudioResource, AudioPlayerStatus } = require('@discordjs/voice');
const YouTube = require('youtube-sr').default;

module.exports = {
    data: new SlashCommandBuilder()
        .setName('play')
        .setDescription('Play a song from YouTube')
        .addStringOption(option =>
            option.setName('query')
                .setDescription('Song name or YouTube link')
                .setRequired(true)
        ),
    async execute(interaction, client, config) {
        const query = interaction.options.getString('query');
        const voiceChannel = interaction.member.voice.channel;

        if (!voiceChannel) {
            return interaction.reply({ content: '❌ You need to be in a voice channel to play music.', ephemeral: true });
        }

        await interaction.deferReply();

        let songInfo;
        if (ytdl.validateURL(query)) {
            songInfo = await ytdl.getInfo(query);
        } else {
            const search = await YouTube.search(query, { limit: 1 });
            if (!search.length) return interaction.editReply('❌ No results found.');
            songInfo = await ytdl.getInfo(search[0].url);
        }

        const connection = joinVoiceChannel({
            channelId: voiceChannel.id,
            guildId: interaction.guildId,
            adapterCreator: interaction.guild.voiceAdapterCreator,
        });

        const player = createAudioPlayer();
        const resource = createAudioResource(ytdl(songInfo.videoDetails.video_url, { filter: 'audioonly', quality: 'highestaudio' }));

        player.play(resource);
        connection.subscribe(player);

        player.on(AudioPlayerStatus.Idle, () => connection.destroy());

        const embed = new EmbedBuilder()
            .setTitle(songInfo.videoDetails.title)
            .setURL(songInfo.videoDetails.video_url)
            .setDescription(`Now playing in ${voiceChannel.name}`)
            .setThumbnail(songInfo.videoDetails.thumbnails[0].url)
            .setColor('#00ff00');

        interaction.editReply({ embeds: [embed] });
    }
};
