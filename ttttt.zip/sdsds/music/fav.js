const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const ytdl = require('ytdl-core');
const { joinVoiceChannel, createAudioPlayer, createAudioResource, AudioPlayerStatus } = require('@discordjs/voice');
const YouTube = require('youtube-sr').default;

// Object to store each user's favorite songs
const userFavorites = {};

module.exports = {
    data: new SlashCommandBuilder()
        .setName('fav')
        .setDescription('Add a song to your favorites or play your favorite list')
        .addStringOption(option =>
            option.setName('query')
                .setDescription('Song name or YouTube link')
                .setRequired(false)
        )
        .addBooleanOption(option =>
            option.setName('play')
                .setDescription('Play your favorite list')
                .setRequired(false)
        ),
    async execute(interaction, client, config) {
        const query = interaction.options.getString('query');
        const playFav = interaction.options.getBoolean('play');

        const voiceChannel = interaction.member.voice.channel;
        if (!voiceChannel) return interaction.reply({ content: '❌ You need to be in a voice channel.', ephemeral: true });

        if (!userFavorites[interaction.user.id]) userFavorites[interaction.user.id] = [];

        // Add to favorites
        if (query) {
            let songUrl;
            if (ytdl.validateURL(query)) {
                songUrl = query;
            } else {
                const search = await YouTube.search(query, { limit: 1 });
                if (!search.length) return interaction.reply('❌ No results found.');
                songUrl = search[0].url;
            }
            userFavorites[interaction.user.id].push(songUrl);
            return interaction.reply({ content: `✅ Added to your favorites! Total: ${userFavorites[interaction.user.id].length}`, ephemeral: true });
        }

        // Play favorites
        if (playFav) {
            const favs = userFavorites[interaction.user.id];
            if (!favs.length) return interaction.reply({ content: '❌ You have no favorite songs.', ephemeral: true });

            await interaction.deferReply();

            const connection = joinVoiceChannel({
                channelId: voiceChannel.id,
                guildId: interaction.guildId,
                adapterCreator: interaction.guild.voiceAdapterCreator
            });

            const player = createAudioPlayer();

            async function playNext(index = 0) {
                if (index >= favs.length) {
                    connection.destroy();
                    return interaction.followUp({ content: '✅ Finished playing your favorite list.' });
                }
                const songInfo = await ytdl.getInfo(favs[index]);
                const resource = createAudioResource(ytdl(songInfo.videoDetails.video_url, { filter: 'audioonly', quality: 'highestaudio' }));
                player.play(resource);
                connection.subscribe(player);

                const embed = new EmbedBuilder()
                    .setTitle(songInfo.videoDetails.title)
                    .setURL(songInfo.videoDetails.video_url)
                    .setThumbnail(songInfo.videoDetails.thumbnails[0].url)
                    .setDescription(`Now playing in ${voiceChannel.name}`)
                    .setColor('#00ff00');

                interaction.followUp({ embeds: [embed] });

                player.once(AudioPlayerStatus.Idle, () => playNext(index + 1));
            }

            playNext();
        }
    }
};
