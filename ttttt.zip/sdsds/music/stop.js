const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getVoiceConnection } = require('@discordjs/voice');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('stop')
        .setDescription('Stop the music and leave the voice channel'),
    async execute(interaction, client, config) {
        const voiceChannel = interaction.member.voice.channel;
        if (!voiceChannel) return interaction.reply({ content: '❌ You are not in a voice channel.', ephemeral: true });

        const connection = getVoiceConnection(interaction.guildId);
        if (!connection) return interaction.reply({ content: '❌ No music is playing.', ephemeral: true });

        connection.destroy();

        const embed = new EmbedBuilder()
            .setDescription(`⏹️ Music stopped and left ${voiceChannel.name}`)
            .setColor('#FF0000');

        interaction.reply({ embeds: [embed] });
    }
};
