const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getVoiceConnection, AudioPlayerStatus } = require('@discordjs/voice');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('loop')
        .setDescription('Toggle loop for the current song'),
    async execute(interaction, client, config) {
        const connection = getVoiceConnection(interaction.guildId);
        if (!connection) return interaction.reply({ content: '❌ No music is playing.', ephemeral: true });

        if (!connection.state.subscription) return interaction.reply({ content: '❌ No audio player found.', ephemeral: true });

        const player = connection.state.subscription.player;
        player.loop = !player.loop; // toggle loop (custom property)

        const embed = new EmbedBuilder()
            .setDescription(player.loop ? '🔁 Loop enabled' : '⏹️ Loop disabled')
            .setColor(player.loop ? '#00ff00' : '#FF0000');

        interaction.reply({ embeds: [embed] });
    }
};
