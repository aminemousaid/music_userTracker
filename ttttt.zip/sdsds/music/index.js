const play = require('./play');
const stop = require('./stop');
const loop = require('./loop');
const fav = require('./fav');

module.exports = {
    commands: new Map([
        [play.name, play],
        [stop.name, stop],
        [loop.name, loop],
        [fav.name, fav]
    ])
};
